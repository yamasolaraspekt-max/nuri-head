@extends('admin.layouts.app')
@section('title') Anfragevorschläge @stop

@section('style')
<link rel="stylesheet" href="{{ asset('css/select2.min.css') }}">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

<style>
  :root{
    --app-bg:#f6f8fb;
    --card-bg:#fff;
    --muted:#6b7280;
    --shade:#eef2f7;
    --ring:rgba(0,0,0,.06);
    --radius:14px;
  }
  body{ background:var(--app-bg)!important; }

  /* App shell */
  .app-shell{
    display:grid;
    grid-template-columns: 1fr;
    gap: 1.2rem;
  }
  @media (min-width: 1200px){
    .app-shell{
      grid-template-columns: minmax(0,1fr) 340px; /* main + sidebar */
      align-items: start;
    }
  }

  /* Cards */
  .app-card{
    background:var(--card-bg);
    border-radius:var(--radius);
    border:1px solid var(--ring);
    box-shadow:0 8px 28px -18px rgba(0,0,0,.25);
  }
  .app-card .card-head{
    padding: 1rem 1.2rem;
    border-bottom:1px solid var(--ring);
    display:flex; align-items:center; justify-content:space-between; gap:.75rem;
    position: sticky; top: 0; background: var(--card-bg); z-index: 5;
    border-top-left-radius: var(--radius); border-top-right-radius: var(--radius);
  }

  /* Toolbar */
  .toolbar{
    display:flex; gap:.5rem; flex-wrap:wrap; align-items:center;
  }
  .btn-app{
    border-radius:10px; display:inline-flex; align-items:center; gap:.4rem;
    padding:.45rem .7rem;
  }

  /* Inputs */
  .searchbar{
    border-radius:10px!important; border-color:#d1d9e6!important;
  }
  .select2-container .select2-selection{
    height:42px!important; border-radius:10px!important; border-color:#d1d9e6!important;
  }

  /* Tables */
  .table-wrap{ padding: .8rem 1.2rem 1.2rem; }
  .table thead th{
    background:#f2f5fa; color:#475569; font-weight:700; border-top:0; position:sticky; top:0; z-index:2;
  }
  .table td, .table th{ vertical-align:middle; }
  .table-rounded{
    border-radius:12px; overflow:hidden; border:1px solid var(--ring);
  }

  /* Badges */
  .chip{ display:inline-flex; align-items:center; gap:.35rem; padding:.2rem .5rem;
         border-radius:999px; font-size:.75rem; border:1px solid var(--ring); background:#fafbff; }
  .chip-muted{ background:#eef2f7; }
  .chip-int{ background:#eef6ff; }
  .chip-ext{ background:#eefbf3; }

  /* Empty state */
  .empty{
    border:1px dashed #cdd6e4; border-radius:12px; padding:1rem; text-align:center; color:var(--muted);
    background:#fafcff;
  }

  /* Sidebar employees */
  .emp-item{ display:flex; gap:.75rem; padding:.5rem; border-radius:.75rem; border:1px solid var(--ring); background:#fff; }
  .emp-img{ width:38px; height:38px; border-radius:999px; object-fit:cover; }

  /* Modal polish */
  .modal-content{ border-radius:14px; }

  /* Saved filter bar */
  .saved-filters{
    background:#f9fafb;
    border-radius:12px;
    border:1px solid rgba(148,163,184,.25);
    padding:.75rem .9rem;
    margin-bottom:.75rem;
  }
  .saved-filters .form-control,
  .saved-filters .select2-container--default .select2-selection--single,
  .saved-filters .select2-container--default .select2-selection--multiple{
    font-size:.8rem;
  }

  /* Position dropdown with avatars (Select2 templates) */
  .pos-option{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:.5rem;
  }
  .pos-option-label{
    font-size:.85rem;
    color:#111827;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
  }
  .pos-option-avatars{
    display:flex;
    align-items:center;
    gap:2px;
  }
  .pos-avatar{
    width:22px;
    height:22px;
    border-radius:999px;
    object-fit:cover;
    border:1px solid #e5e7eb;
  }
  .pos-avatar-more{
    font-size:.7rem;
    color:#6b7280;
    padding:0 4px;
  }

  .form-check-inline{
    display:flex;
    align-items:center;
    gap:.25rem;
  }
</style>
@endsection

@section('content')

    <!-- BEGIN: Content-->
    <div class="app-content"> 
        <div class="content-wrapper">
            
            <div class="content-body"> 
                     <div class="app-shell"> 
                        <!-- =========================
                            MAIN: Builder + Records
                        ========================== -->
                        <section class="app-card">

                            <div class="card-head">
                                <h4 class="m-0 d-flex align-items-center gap-2">
                                    <i data-feather="layers"></i>
                                    <span>Anfragevorschläge</span> 
                                </h4>

                                <div class="toolbar">
                                    <input id="savedRecordsSearch" class="form-control searchbar" style="min-width:260px"
                                        placeholder="🔍 Nach Stufe, Produkt, Abteilung, Leistung, Position suchen…">

                                    <button id="addRow" class="btn btn-outline-primary btn-app">
                                        <i data-feather="plus"></i> Hinzufügen
                                    </button>
                                    <button id="saveRows" class="btn btn-success btn-app">
                                        <i data-feather="save"></i> Speichern
                                    </button>

                                    <div class="form-check form-check-inline ms-1">
                                        <input class="form-check-input" type="checkbox" id="copyInquiryToStages">
                                        <label class="form-check-label small text-muted" for="copyInquiryToStages">
                                            Anfrage auf andere Stufen kopieren
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="table-wrap">
                                <!-- Builder table -->
                                <div class="table-responsive table-rounded mb-3">
                                    <table class="table align-middle mb-0" id="dynamicTable">
                                        <thead>
                                            <tr>
                                                <th style="width:12rem">Stufe</th>
                                                <th style="width:16rem">Produkt</th>
                                                <th style="width:16rem">Leistung</th>
                                                <th style="width:16rem">Abteilung</th>
                                                <th>Positionen</th>
                                                <th class="text-center" style="width:6rem">Aktion</th>
                                            </tr>
                                        </thead>
                                        <tbody id="rowContainer">
                                            <tr>
                                                <td colspan="6">
                                                    <div class="empty">
                                                        Noch keine Eingaben. Klicken Sie auf <strong>Hinzufügen</strong>, um eine Zeile zu erstellen.
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <!-- Saved records header + filters -->
                                <div class="d-flex align-items-center justify-content-between mt-4 mb-2">
                                    <h5 class="m-0 text-secondary d-flex align-items-center gap-2">
                                        <i data-feather="clock"></i> Gespeicherte Vorschläge
                                    </h5>
                                    <div class="d-flex align-items-center gap-2">
                                        <button id="btnBulkDuplicate" class="btn btn-sm btn-outline-primary" disabled>
                                            <i data-feather="copy"></i> Duplizieren
                                        </button>
                                        <button id="btnBulkDelete" class="btn btn-sm btn-outline-danger" disabled>
                                            <i data-feather="trash-2"></i> Löschen
                                        </button>
                                    </div>
                                </div>

                                <div class="saved-filters">
                                    <div class="row g-2">
                                        <div class="col-md-3 col-sm-6">
                                            <label class="small text-muted mb-1">Produkt</label>
                                            <select id="savedFilterProduct" class="form-control">
                                                <option value="">Alle Produkte</option>
                                            </select>
                                        </div>
                                        <div class="col-md-3 col-sm-6">
                                            <label class="small text-muted mb-1">Leistung</label>
                                            <select id="savedFilterService" class="form-control">
                                                <option value="">Alle Leistungen</option>
                                            </select>
                                        </div>
                                        <div class="col-md-3 col-sm-6">
                                            <label class="small text-muted mb-1">Abteilung</label>
                                            <select id="savedFilterDepartment" class="form-control">
                                                <option value="">Alle Abteilungen</option>
                                            </select>
                                        </div>
                                        <div class="col-md-3 col-sm-6">
                                            <label class="small text-muted mb-1">Sortierung</label>
                                            <div class="d-flex gap-1">
                                                <select id="savedSortBy" class="form-control">
                                                    <option value="stage">Stufe</option>
                                                    <option value="product">Produkt</option>
                                                    <option value="service">Leistung</option>
                                                    <option value="department">Abteilung</option>
                                                </select>
                                                <button id="savedSortDirToggle" type="button" class="btn btn-light btn-sm" title="Sortierreihenfolge">
                                                    <span data-dir="asc">↑</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row g-2 mt-2">
                                        <div class="col-md-6">
                                            <label class="small text-muted mb-1">Position Intern (Innendienst)</label>
                                            <select id="savedFilterPosInternal" class="form-control" multiple></select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="small text-muted mb-1">Position Extern (Außendienst)</label>
                                            <select id="savedFilterPosExternal" class="form-control" multiple></select>
                                        </div>
                                    </div>
                                </div>

                                <!-- Saved records table -->
                                <div class="table-responsive table-rounded" id="savedRecordsTable">
                                    <div class="empty">Keine Datensätze gefunden.</div>
                                </div>
                            </div>

                        </section>

                        <!-- =========================
                            SIDEBAR: Mitarbeiter
                        ========================== -->
                        <aside class="app-card p-3 p-lg-4">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <h5 class="m-0 d-flex align-items-center gap-2">
                                    <i data-feather="users"></i> Mitarbeiter
                                </h5>
                                <span id="employeeBadge" class="chip chip-muted">0 gefunden</span>
                            </div>

                            <div class="mb-3">
                                <div class="d-flex align-items-center gap-2 mb-1">
                                    <span class="chip chip-int"><i data-feather="shield"></i> Intern</span>
                                    <span id="employeeCountInternal" class="text-muted small">0</span>
                                </div>
                                <div id="employeeListInternal" class="d-grid gap-2">
                                    <div class="empty">Keine internen Mitarbeiter ausgewählt.</div>
                                </div>
                            </div>

                            <div>
                                <div class="d-flex align-items-center gap-2 mb-1">
                                    <span class="chip chip-ext"><i data-feather="users"></i> Extern</span>
                                    <span id="employeeCountExternal" class="text-muted small">0</span>
                                </div>
                                <div id="employeeListExternal" class="d-grid gap-2">
                                    <div class="empty">Keine externen Mitarbeiter ausgewählt.</div>
                                </div>
                            </div>
                        </aside>
                    </div>
                </div>
            </div>

            <!-- =========================
                Edit Modal
            ========================== -->
            <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-scrollable">
                    <div class="modal-content">
                        <form id="editForm">
                            <div class="modal-header">
                                <h5 class="modal-title d-flex align-items-center gap-2">
                                    <i data-feather="edit-3"></i> Vorschlag bearbeiten
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Schließen"></button>
                            </div>

                            <div class="modal-body">
                                <input type="hidden" id="editId">

                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Stufe</label>
                                        <select id="editStage" class="form-control" style="width:100%">
                                            <option value="">Stufe wählen</option>
                                            <option value="inquiry">Anfrage</option>
                                            <option value="lead">Lead</option>
                                            <option value="offer">Angebot</option>
                                            <option value="deals">Abschluss</option>
                                            <option value="project">Projekt</option>
                                            <option value="ticket">Ticket</option>
                                        </select>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="form-label">Produkt</label>
                                        <select id="editProduct" class="form-control" style="width:100%"></select>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="form-label">Leistung</label>
                                        <select id="editService" class="form-control" style="width:100%"></select>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="form-label">Abteilung</label>
                                        <select id="editDepartment" class="form-control" style="width:100%"></select>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="form-label"><i data-feather="shield"></i> Intern</label>
                                        <select id="editPositionsInternal" class="form-control" multiple style="width:100%"></select>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="form-label"><i data-feather="users"></i> Extern</label>
                                        <select id="editPositionsExternal" class="form-control" multiple style="width:100%"></select>
                                    </div>
                                </div>
                            </div>

                            <div class="modal-footer">
                                <button type="submit" class="btn btn-success">
                                    <i data-feather="check"></i> Aktualisieren
                                </button>
                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Abbrechen</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
    </div>
    <!-- END: Content-->
@stop
 @section('script')
<script src="{{ asset('js/select2.min.js') }}"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
  document.addEventListener('DOMContentLoaded', () => {
    if (window.feather) feather.replace();
  });
</script>

<script>
$(document).ready(function () {
    let articleGroups = [];
    let departments = [];
    let allSavedRecords = [];
    let positionEmployeeMap = {};

    const STAGES_ALL = ['inquiry', 'lead', 'offer', 'deals', 'project', 'ticket'];
    const STAGES_COPY_TARGETS = ['lead', 'offer', 'deals', 'project', 'ticket'];
    const EMPTY_ROW_HTML = `
        <tr>
            <td colspan="6">
                <div class="empty">
                    Noch keine Eingaben. Klicken Sie auf <strong>Hinzufügen</strong>, um eine Zeile zu erstellen.
                </div>
            </td>
        </tr>
    `;

    init();

    function init() {
        initStaticSelect2();
        showFlashMessages();
        bindGlobalEvents();
        fetchData();
        fetchSavedRecords();
    }

    function initStaticSelect2() {
        if ($('#phase_id').length) {
            $('#phase_id').select2();
        }

        $('#savedFilterProduct, #savedFilterService, #savedFilterDepartment').select2({
            width: '100%',
            placeholder: 'Alle',
            allowClear: true
        });

        $('#savedFilterPosInternal, #savedFilterPosExternal').select2({
            width: '100%',
            placeholder: 'Alle Positionen',
            allowClear: true
        });
    }

    function showFlashMessages() {
        @if(Session::has('update_msg'))
            toastr.success("{{ session('update_msg') }}");
        @endif

        @if(Session::has('save_msg'))
            toastr.success("{{ session('save_msg') }}");
        @endif

        @if(Session::has('delete_msg'))
            toastr.error("{{ session('delete_msg') }}");
        @endif
    }

    function bindGlobalEvents() {
        $('#addRow').on('click', addRow);
        $('#saveRows').on('click', saveRows);
        $('#copyInquiryToStages').on('change', handleCopyInquiryToggle);

        $(document).on('input', '#savedRecordsSearch', applySavedFiltersAndSort);

        $('#savedFilterProduct, #savedFilterService, #savedFilterDepartment').on('change', applySavedFiltersAndSort);
        $('#savedFilterPosInternal, #savedFilterPosExternal').on('change', applySavedFiltersAndSort);
        $('#savedSortBy').on('change', applySavedFiltersAndSort);

        $('#savedSortDirToggle').on('click', function () {
            const $span = $(this).find('span');
            const current = $span.data('dir') || 'asc';
            const next = current === 'asc' ? 'desc' : 'asc';

            $span.data('dir', next);
            $span.text(next === 'asc' ? '↑' : '↓');

            applySavedFiltersAndSort();
        });

        $('#btnBulkDuplicate').on('click', handleBulkDuplicate);
        $('#btnBulkDelete').on('click', handleBulkDelete);

        $('#editForm').on('submit', handleEditFormSubmit);
    }

    function fetchData() {
        $.get('/product-position/article-groups', function (data) {
            articleGroups = data || [];
        });

        $.get('/product-position/departments', function (data) {
            departments = data || [];
        });
    }

    function fetchSavedRecords() {
        $.get('/product-position/records', function (records) {
            allSavedRecords = records || [];
            buildSavedFilterOptions(allSavedRecords);
            applySavedFiltersAndSort();
        });
    }

    function ensureEmptyRowIfNeeded() {
        if (!$('#rowContainer tr').length) {
            $('#rowContainer').append(EMPTY_ROW_HTML);
        }
    }

    function clearEmptyRow() {
        $('#rowContainer').find('.empty').closest('tr').remove();
    }

    function addRow() {
        clearEmptyRow();

        const rowHtml = `
            <tr>
                <td>
                    <select class="form-control stage-select">
                        <option value="">Stufe wählen</option>
                        <option value="inquiry">Anfrage</option>
                        <option value="lead">Lead</option>
                        <option value="offer">Angebot</option>
                        <option value="deals">Abschluss</option>
                        <option value="project">Projekt</option>
                        <option value="ticket">Ticket</option>
                    </select>
                </td>
                <td>
                    <select class="form-control produkt-select">
                        <option value="">Produkt wählen</option>
                    </select>
                </td>
                <td>
                    <select class="form-control service-select">
                        <option value="">Leistung wählen</option>
                    </select>
                </td>
                <td>
                    <select class="form-control department-select">
                        <option value="">Abteilung wählen</option>
                    </select>
                </td>
                <td>
                    <div class="space-y-2">
                        <div>
                            <label class="form-label mb-1 small text-muted">
                                <i data-feather="shield"></i> Intern (Innendienst)
                            </label>
                            <select class="form-control position-internal-select" multiple="multiple" style="width:100%"></select>
                        </div>
                        <div>
                            <label class="form-label mb-1 small text-muted">
                                <i data-feather="users"></i> Extern (Außendienst)
                            </label>
                            <select class="form-control position-external-select" multiple="multiple" style="width:100%"></select>
                        </div>
                    </div>
                </td>
                <td class="text-center">
                    <button type="button" class="btn btn-sm btn-outline-danger removeRow" title="Zeile entfernen">
                        <i data-feather="trash-2"></i>
                    </button>
                </td>
            </tr>
        `;

        $('#rowContainer').append(rowHtml);

        const $newRow = $('#rowContainer tr:last');

        populateProductOptions($newRow.find('.produkt-select'));
        populateDepartmentOptions($newRow.find('.department-select'));

        $newRow.find('.stage-select, .produkt-select, .service-select, .department-select').select2({
            width: '100%'
        });

        initPositionSelect2($newRow.find('.position-internal-select'));
        initPositionSelect2($newRow.find('.position-external-select'));

        bindRowEvents($newRow);

        if (window.feather) {
            feather.replace();
        }

        return $newRow;
    }

    function populateProductOptions($select) {
        $select.empty().append('<option value="">Produkt wählen</option>');

        articleGroups.forEach(group => {
            $select.append(`<option value="${group.id}">${group.article_group}</option>`);
        });
    }

    function populateDepartmentOptions($select) {
        $select.empty().append('<option value="">Abteilung wählen</option>');

        departments.forEach(dept => {
            $select.append(`<option value="${dept.id}">${dept.department_name}</option>`);
        });
    }

    function bindRowEvents($row) {
        $row.find('.removeRow').on('click', function () {
            const $tr = $(this).closest('tr');
            const isClone = $tr.attr('data-auto-inquiry-clone') === '1';

            $tr.remove();
            ensureEmptyRowIfNeeded();

            if (isClone && !$('#rowContainer tr[data-auto-inquiry-clone="1"]').length) {
                $('#copyInquiryToStages').prop('checked', false);
            }
        });

        $row.find('.produkt-select').on('change', function () {
            const productId = $(this).val();
            const $serviceSelect = $(this).closest('tr').find('.service-select');

            $serviceSelect.empty().append('<option value="">Leistung wählen</option>');

            if (!productId) {
                $serviceSelect.trigger('change.select2');
                return;
            }

            $.get(`/product-position/services/${productId}`, function (data) {
                (data || []).forEach(service => {
                    $serviceSelect.append(`<option value="${service.id}">${service.label}</option>`);
                });

                $serviceSelect.trigger('change.select2');
            });
        });

        $row.find('.department-select').on('change', function () {
            const departmentId = $(this).val();
            const $currentRow = $(this).closest('tr');
            const $posInt = $currentRow.find('.position-internal-select');
            const $posExt = $currentRow.find('.position-external-select');

            $posInt.empty();
            $posExt.empty();

            if (!departmentId) {
                $posInt.trigger('change');
                $posExt.trigger('change');
                return;
            }

            $.get(`/product-position/positions/${departmentId}`, function (data) {
                (data || []).forEach(pos => {
                    const optionHtml = `<option value="${pos.id}" data-department-id="${departmentId}">${pos.position}</option>`;
                    $posInt.append(optionHtml);
                    $posExt.append(optionHtml);
                });

                initPositionSelect2($posInt);
                initPositionSelect2($posExt);
                buildPositionEmployeeMapForDepartment(departmentId, data || []);
            });
        });
    }

    function handleCopyInquiryToggle() {
        const checked = $('#copyInquiryToStages').is(':checked');

        if (!checked) {
            removeInquiryClones();
            return;
        }

        const $rows = $('#rowContainer tr').filter(function () {
            return !$(this).find('.empty').length;
        });

        if (!$rows.length) {
            $('#copyInquiryToStages').prop('checked', false);

            Swal.fire({
                icon: 'info',
                title: 'Keine Anfrage-Zeile',
                text: 'Legen Sie zuerst eine Anfrage-Zeile an und füllen Sie alle Felder aus.',
                timer: 2200,
                showConfirmButton: false
            });

            return;
        }

        const $master = $rows.first();

        if (!isInquiryRowComplete($master)) {
            $('#copyInquiryToStages').prop('checked', false);

            Swal.fire({
                icon: 'info',
                title: 'Anfrage unvollständig',
                text: 'Die erste Zeile muss Stufe "Anfrage" haben und Produkt, Leistung, Abteilung und mindestens eine Position enthalten.',
                timer: 2600,
                showConfirmButton: false
            });

            return;
        }

        Swal.fire({
            icon: 'question',
            title: 'Auf andere Stufen kopieren?',
            html: 'Die Anfrage-Zeile wird für <strong>Lead, Angebot, Abschluss, Projekt und Ticket</strong> kopiert. Wenn die Leistung <strong>Komplett</strong> ist, werden zusätzlich alle Einzel-Leistungen erzeugt.',
            showCancelButton: true,
            confirmButtonText: 'Ja, kopieren',
            cancelButtonText: 'Abbrechen'
        }).then(result => {
            if (!result.isConfirmed) {
                $('#copyInquiryToStages').prop('checked', false);
                return;
            }

            removeInquiryClones();
            cloneInquiryRowToOtherStages($master);
        });
    }

    function isInquiryRowComplete($row) {
        const stage = $row.find('.stage-select').val();
        const produkt = $row.find('.produkt-select').val();
        const service = $row.find('.service-select').val();
        const department = $row.find('.department-select').val();
        const internal = $row.find('.position-internal-select').val() || [];
        const external = $row.find('.position-external-select').val() || [];

        if (stage !== 'inquiry') return false;
        if (!produkt || !service || !department) return false;
        if (!internal.length && !external.length) return false;

        return true;
    }

    function removeInquiryClones() {
        $('#rowContainer tr[data-auto-inquiry-clone="1"]').remove();
        ensureEmptyRowIfNeeded();
    }

    function getSelectedServiceLabel($serviceSelect) {
        return $.trim($serviceSelect.find('option:selected').text() || '').toLowerCase();
    }

    function getServicesToClone($sourceRow) {
        const $serviceSelect = $sourceRow.find('.service-select');
        const selectedServiceId = $serviceSelect.val();
        const selectedLabel = getSelectedServiceLabel($serviceSelect);
        const serviceOptions = [];

        $serviceSelect.find('option').each(function () {
            const value = $(this).val();
            const label = $.trim($(this).text());

            if (!value) return;

            serviceOptions.push({
                id: value,
                label: label,
                normalized: label.toLowerCase()
            });
        });

        if (selectedLabel === 'komplett') {
            return serviceOptions;
        }

        const found = serviceOptions.find(service => String(service.id) === String(selectedServiceId));
        return found ? [found] : [];
    }

    function createClonedRow(config) {
        const {
            stageVal,
            produktVal,
            departmentVal,
            serviceToSet,
            masterServiceHtml,
            masterInternalHtml,
            masterExternalHtml,
            internalVals,
            externalVals
        } = config;

        const $row = addRow();
        $row.attr('data-auto-inquiry-clone', '1');

        const $stageSelect = $row.find('.stage-select');
        const $produktSelect = $row.find('.produkt-select');
        const $serviceSelect = $row.find('.service-select');
        const $deptSelect = $row.find('.department-select');
        const $posInt = $row.find('.position-internal-select');
        const $posExt = $row.find('.position-external-select');

        $stageSelect.val(stageVal).trigger('change.select2');

        if (produktVal) {
            $produktSelect.val(produktVal).trigger('change.select2');
        }

        if (departmentVal) {
            $deptSelect.val(departmentVal).trigger('change.select2');
        }

        $serviceSelect.html(masterServiceHtml);
        if (serviceToSet && serviceToSet.id) {
            $serviceSelect.val(serviceToSet.id).trigger('change.select2');
        }

        $posInt.html(masterInternalHtml);
        $posExt.html(masterExternalHtml);

        initPositionSelect2($posInt);
        initPositionSelect2($posExt);

        if (internalVals.length) {
            $posInt.val(internalVals).trigger('change.select2');
        }

        if (externalVals.length) {
            $posExt.val(externalVals).trigger('change.select2');
        }

        return $row;
    }

    function cloneInquiryRowToOtherStages($sourceRow) {
        const produktVal = $sourceRow.find('.produkt-select').val();
        const departmentVal = $sourceRow.find('.department-select').val();
        const internalVals = $sourceRow.find('.position-internal-select').val() || [];
        const externalVals = $sourceRow.find('.position-external-select').val() || [];

        const $masterService = $sourceRow.find('.service-select');
        const $masterPosInt = $sourceRow.find('.position-internal-select');
        const $masterPosExt = $sourceRow.find('.position-external-select');

        const servicesToClone = getServicesToClone($sourceRow);

        if (!servicesToClone.length) {
            $('#copyInquiryToStages').prop('checked', false);

            Swal.fire({
                icon: 'info',
                title: 'Keine Leistung gefunden',
                text: 'Für die Anfrage-Zeile konnte keine gültige Leistung ermittelt werden.',
                timer: 2200,
                showConfirmButton: false
            });

            return;
        }

        STAGES_COPY_TARGETS.forEach(stageVal => {
            servicesToClone.forEach(serviceToSet => {
                createClonedRow({
                    stageVal,
                    produktVal,
                    departmentVal,
                    serviceToSet,
                    masterServiceHtml: $masterService.html(),
                    masterInternalHtml: $masterPosInt.html(),
                    masterExternalHtml: $masterPosExt.html(),
                    internalVals,
                    externalVals
                });
            });
        });
    }

    function renderEmployeesList(employees, containerSelector) {
        let html = '';

        if (!employees || !employees.length) {
            html = '<div class="empty">Keine Mitarbeiter gefunden.</div>';
        } else {
            html = employees.map(emp => {
                const badges = (emp.positions || []).map(position => {
                    return `<span class="badge bg-primary me-1">${position}</span>`;
                }).join('');

                return `
                    <div class="emp-item">
                        <img class="emp-img" src="/images/employee/${emp.image}" alt="${emp.name}">
                        <div>
                            <div><strong>${emp.name} ${emp.lastname}</strong></div>
                            <div>${badges}</div>
                        </div>
                    </div>
                `;
            }).join('');
        }

        $(containerSelector).html(html);
    }

    function getPositionEmployeesForOption(optionElement) {
        if (!optionElement) return [];

        const $opt = $(optionElement);
        const deptId = $opt.data('department-id');
        const posName = $.trim($opt.text());

        if (!deptId || !posName) return [];

        const departmentMap = positionEmployeeMap[deptId] || {};
        return departmentMap[posName] || [];
    }

    function positionTemplateResult(state) {
        if (!state.id) return state.text;

        const employees = getPositionEmployeesForOption(state.element);
        const $container = $('<span class="pos-option"></span>');
        const $label = $('<span class="pos-option-label"></span>').text(state.text);
        const $avatarsWrap = $('<span class="pos-option-avatars"></span>');

        if (employees.length) {
            employees.slice(0, 3).forEach(emp => {
                const $img = $('<img class="pos-avatar" />')
                    .attr('src', '/images/employee/' + emp.image)
                    .attr('alt', emp.name);

                $avatarsWrap.append($img);
            });

            if (employees.length > 3) {
                $avatarsWrap.append(
                    $('<span class="pos-avatar-more"></span>').text('+' + (employees.length - 3))
                );
            }
        }

        $container.append($label).append($avatarsWrap);
        return $container;
    }

    function positionTemplateSelection(state) {
        if (!state.id) return state.text;

        const employees = getPositionEmployeesForOption(state.element);
        const $container = $('<span class="pos-option"></span>');
        const $label = $('<span class="pos-option-label"></span>').text(state.text);
        const $avatarsWrap = $('<span class="pos-option-avatars"></span>');

        if (employees.length) {
            employees.slice(0, 2).forEach(emp => {
                const $img = $('<img class="pos-avatar" />')
                    .attr('src', '/images/employee/' + emp.image)
                    .attr('alt', emp.name);

                $avatarsWrap.append($img);
            });

            if (employees.length > 2) {
                $avatarsWrap.append(
                    $('<span class="pos-avatar-more"></span>').text('+' + (employees.length - 2))
                );
            }
        }

        $container.append($label).append($avatarsWrap);
        return $container;
    }

    function initPositionSelect2($select) {
        if ($select.hasClass('select2-hidden-accessible')) {
            $select.select2('destroy');
        }

        $select.select2({
            width: '100%',
            templateResult: positionTemplateResult,
            templateSelection: positionTemplateSelection,
            escapeMarkup: function (markup) {
                return markup;
            }
        });
    }

    function buildPositionEmployeeMapForDepartment(departmentId, positionsArray) {
        const ids = (positionsArray || []).map(position => position.id);

        if (!ids.length) return;

        $.post('/product-position/employees', {
            position_ids: { internal: ids, external: [] },
            _token: '{{ csrf_token() }}'
        }, function (employees) {
            const mapByName = {};

            (employees || []).forEach(emp => {
                (emp.positions || []).forEach(posName => {
                    const normalizedName = $.trim(posName);

                    if (!mapByName[normalizedName]) {
                        mapByName[normalizedName] = [];
                    }

                    mapByName[normalizedName].push(emp);
                });
            });

            positionEmployeeMap[departmentId] = mapByName;
        });
    }

    function collectRowsFromBuilder() {
        const rows = [];

        $('#rowContainer tr').each(function () {
            const $row = $(this);

            if ($row.find('.empty').length) return;

            const stage = $row.find('.stage-select').val();
            const produkt = $row.find('.produkt-select').val();
            const service = $row.find('.service-select').val();
            const department = $row.find('.department-select').val();
            const internal = $row.find('.position-internal-select').val() || [];
            const external = $row.find('.position-external-select').val() || [];

            if (stage && produkt && service && department && (internal.length || external.length)) {
                rows.push({
                    stage,
                    produkt,
                    service,
                    department,
                    positions: {
                        internal,
                        external
                    }
                });
            }
        });

        return rows;
    }

    function sameArray(a, b) {
        const arrA = a || [];
        const arrB = b || [];

        if (arrA.length !== arrB.length) return false;

        const sortedA = [...arrA].sort();
        const sortedB = [...arrB].sort();

        for (let i = 0; i < sortedA.length; i++) {
            if (String(sortedA[i]) !== String(sortedB[i])) {
                return false;
            }
        }

        return true;
    }

    function sameRecordKey(existing, row) {
        if ((existing.stage || '') !== row.stage) return false;
        if (String(existing.article_group_id || '') !== String(row.produkt || '')) return false;
        if (String(existing.service_id || '') !== String(row.service || '')) return false;
        if (String(existing.department_id || '') !== String(row.department || '')) return false;

        const existingPositions = existing.position_ids || {};
        const existingInternal = existingPositions.internal || [];
        const existingExternal = existingPositions.external || [];
        const rowInternal = row.positions.internal || [];
        const rowExternal = row.positions.external || [];

        return sameArray(existingInternal, rowInternal) && sameArray(existingExternal, rowExternal);
    }

    function findConflictingRows(rows) {
        const conflicts = [];

        (rows || []).forEach((row, idx) => {
            const matches = (allSavedRecords || []).filter(record => sameRecordKey(record, row));

            if (matches.length) {
                conflicts.push({
                    rowIndex: idx,
                    row,
                    existing: matches
                });
            }
        });

        return conflicts;
    }

    function saveRows() {
        const rows = collectRowsFromBuilder();

        if (!rows.length) {
            Swal.fire({
                icon: 'info',
                title: 'Unvollständige Eingabe',
                text: 'Bitte füllen Sie mindestens eine vollständige Zeile aus.',
                timer: 1800,
                showConfirmButton: false
            });
            return;
        }

        const conflicts = findConflictingRows(rows);

        if (!conflicts.length) {
            doSaveRows(rows);
            return;
        }

        const htmlList = conflicts.map(conflict => {
            const record = conflict.existing[0];
            const serviceName = record.service ? translateService(record.service.phase_section) : '-';
            const productName = record.article_group ? record.article_group.article_group : '-';
            const departmentName = record.department ? record.department.department_name : '-';

            return `<li><strong>${stageLabelDe(conflict.row.stage)}</strong> / ${productName} / ${serviceName} / ${departmentName}</li>`;
        }).join('');

        Swal.fire({
            icon: 'warning',
            title: 'Doppelte Vorschläge gefunden',
            html: `
                <p>Für einige Kombinationen existieren bereits Vorschläge:</p>
                <ul style="text-align:left;">${htmlList}</ul>
                <p>Wie möchten Sie fortfahren?</p>
            `,
            showCancelButton: true,
            showDenyButton: true,
            confirmButtonText: 'Überschreiben',
            denyButtonText: 'Ignorieren',
            cancelButtonText: 'Abbrechen'
        }).then(result => {
            if (result.isConfirmed) {
                const idsToDelete = [];

                conflicts.forEach(conflict => {
                    conflict.existing.forEach(record => idsToDelete.push(record.id));
                });

                const uniqueIds = [...new Set(idsToDelete)];

                $.ajax({
                    url: '/product-position/bulk-delete',
                    method: 'POST',
                    data: { ids: uniqueIds },
                    headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
                    success: function () {
                        doSaveRows(rows);
                    }
                });
            } else if (result.isDenied) {
                const conflictIndexes = new Set(conflicts.map(conflict => conflict.rowIndex));
                const filteredRows = rows.filter((row, idx) => !conflictIndexes.has(idx));

                if (!filteredRows.length) {
                    Swal.fire({
                        icon: 'info',
                        title: 'Keine neuen Vorschläge',
                        text: 'Alle Zeilen sind bereits vorhanden.',
                        timer: 1800,
                        showConfirmButton: false
                    });
                    return;
                }

                doSaveRows(filteredRows);
            }
        });
    }

    function doSaveRows(rows) {
        if (!rows.length) return;

        $.ajax({
            url: '/product-position/save',
            method: 'POST',
            data: { rows },
            headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
            success: function (response) {
                Swal.fire({
                    icon: 'success',
                    title: 'Aktualisiert',
                    text: response.message,
                    timer: 1500,
                    showConfirmButton: false
                });

                $('#rowContainer').empty().append(EMPTY_ROW_HTML);
                $('#copyInquiryToStages').prop('checked', false);
                fetchSavedRecords();
            }
        });
    }

    function translateService(value) {
        const map = {
            complete: 'Komplett',
            montage: 'Montage',
            product: 'Produkt',
            plan: 'Planung',
            maintenance: 'Wartung',
            repair: 'Reparatur',
            others: 'Others'
        };

        return map[String(value || '').toLowerCase()] || value;
    }

    function stageLabelDe(value) {
        const map = {
            inquiry: 'Anfrage',
            lead: 'Lead',
            offer: 'Angebot',
            deals: 'Abschluss',
            project: 'Projekt',
            ticket: 'Ticket'
        };

        return map[String(value || '').toLowerCase()] || value || '-';
    }

    function buildSavedFilterOptions(records) {
        const products = new Set();
        const services = new Set();
        const departmentNames = new Set();
        const posIntSet = new Set();
        const posExtSet = new Set();

        (records || []).forEach(record => {
            if (record.article_group && record.article_group.article_group) {
                products.add(record.article_group.article_group);
            }

            if (record.service && record.service.phase_section) {
                services.add(translateService(record.service.phase_section));
            }

            if (record.department && record.department.department_name) {
                departmentNames.add(record.department.department_name);
            }

            (record.position_internal || []).forEach(name => posIntSet.add(name));
            (record.position_external || []).forEach(name => posExtSet.add(name));
        });

        fillSingleFilter('#savedFilterProduct', products, 'Alle Produkte');
        fillSingleFilter('#savedFilterService', services, 'Alle Leistungen');
        fillSingleFilter('#savedFilterDepartment', departmentNames, 'Alle Abteilungen');

        fillMultiFilter('#savedFilterPosInternal', posIntSet);
        fillMultiFilter('#savedFilterPosExternal', posExtSet);
    }

    function fillSingleFilter(selector, valuesSet, placeholder) {
        const $select = $(selector);
        const currentValue = $select.val();

        $select.empty().append(`<option value="">${placeholder}</option>`);

        Array.from(valuesSet).sort().forEach(value => {
            $select.append(`<option value="${value}">${value}</option>`);
        });

        if (currentValue) {
            $select.val(currentValue);
        }

        if ($select.hasClass('select2-hidden-accessible')) {
            $select.trigger('change.select2');
        }
    }

    function fillMultiFilter(selector, valuesSet) {
        const $select = $(selector);
        const selectedValues = $select.val() || [];

        $select.empty();

        Array.from(valuesSet).sort().forEach(value => {
            const selected = selectedValues.includes(value) ? 'selected' : '';
            $select.append(`<option value="${value}" ${selected}>${value}</option>`);
        });

        if ($select.hasClass('select2-hidden-accessible')) {
            $select.trigger('change.select2');
        }
    }

    function applySavedFiltersAndSort() {
        let filtered = [...(allSavedRecords || [])];

        const search = ($('#savedRecordsSearch').val() || '').toLowerCase();
        const filterProduct = $('#savedFilterProduct').val() || '';
        const filterService = $('#savedFilterService').val() || '';
        const filterDepartment = $('#savedFilterDepartment').val() || '';
        const posInternalValues = $('#savedFilterPosInternal').val() || [];
        const posExternalValues = $('#savedFilterPosExternal').val() || [];
        const sortBy = $('#savedSortBy').val() || 'stage';
        const sortDir = $('#savedSortDirToggle span').data('dir') || 'asc';

        filtered = filtered.filter(record => {
            const stage = String(record.stage || '').toLowerCase();
            const product = record.article_group?.article_group || '';
            const productLc = product.toLowerCase();
            const department = record.department?.department_name || '';
            const departmentLc = department.toLowerCase();
            const serviceRaw = record.service ? translateService(record.service.phase_section) : '';
            const serviceLc = serviceRaw.toLowerCase();
            const posIntNames = record.position_internal || [];
            const posExtNames = record.position_external || [];

            const haystack = `${stage} ${productLc} ${departmentLc} ${serviceLc} ${posIntNames.join(' ')} ${posExtNames.join(' ')}`.toLowerCase();

            if (search && !haystack.includes(search)) return false;
            if (filterProduct && product !== filterProduct) return false;
            if (filterService && serviceRaw !== filterService) return false;
            if (filterDepartment && department !== filterDepartment) return false;

            if (posInternalValues.length) {
                const matchesInternal = posInternalValues.every(value => posIntNames.includes(value));
                if (!matchesInternal) return false;
            }

            if (posExternalValues.length) {
                const matchesExternal = posExternalValues.every(value => posExtNames.includes(value));
                if (!matchesExternal) return false;
            }

            return true;
        });

        filtered.sort((a, b) => {
            const getSortValue = record => {
                if (sortBy === 'stage') return String(record.stage || '');
                if (sortBy === 'product') return String(record.article_group?.article_group || '');
                if (sortBy === 'service') return String(record.service ? translateService(record.service.phase_section) : '');
                if (sortBy === 'department') return String(record.department?.department_name || '');
                return '';
            };

            const aValue = getSortValue(a).toLowerCase();
            const bValue = getSortValue(b).toLowerCase();

            if (aValue < bValue) return sortDir === 'asc' ? -1 : 1;
            if (aValue > bValue) return sortDir === 'asc' ? 1 : -1;
            return 0;
        });

        renderSavedRecords(filtered);
    }

    function renderSavedRecords(records) {
        if (!records.length) {
            $('#savedRecordsTable').html('<div class="empty">Keine Datensätze gefunden.</div>');
            return;
        }

        let html = `
            <table class="table table-bordered mb-0">
                <thead>
                    <tr>
                        <th style="width:30px;">
                            <input type="checkbox" id="savedSelectAll">
                        </th>
                        <th>Stufe</th>
                        <th>Produkt</th>
                        <th>Leistung</th>
                        <th>Abteilung</th>
                        <th>Intern</th>
                        <th>Extern</th>
                        <th class="text-nowrap">Aktion</th>
                    </tr>
                </thead>
                <tbody>
        `;

        records.forEach(record => {
            const serviceLabel = record.service ? translateService(record.service.phase_section) : '-';

            const chipsInternal = (record.position_internal || []).map(name => {
                return `<span class="badge bg-secondary me-1">${name}</span>`;
            }).join('') || '-';

            const chipsExternal = (record.position_external || []).map(name => {
                return `<span class="badge bg-info me-1">${name}</span>`;
            }).join('') || '-';

            html += `
                <tr>
                    <td>
                        <input type="checkbox" class="savedRowCheckbox" data-id="${record.id}">
                    </td>
                    <td>${stageLabelDe(record.stage)}</td>
                    <td>${record.article_group ? record.article_group.article_group : '-'}</td>
                    <td>${serviceLabel}</td>
                    <td>${record.department ? record.department.department_name : '-'}</td>
                    <td>${chipsInternal}</td>
                    <td>${chipsExternal}</td>
                    <td class="text-nowrap">
                        <button class="btn btn-sm btn-outline-info viewEmployees"
                                title="Mitarbeiter ansehen"
                                data-positions='${JSON.stringify(record.position_ids)}'>
                            <i data-feather="eye"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-warning editRecord"
                                title="Bearbeiten"
                                data-id="${record.id}"
                                data-stage="${record.stage}"
                                data-produkt="${record.article_group_id}"
                                data-service-id="${record.service_id}"
                                data-department="${record.department_id}"
                                data-positions='${JSON.stringify(record.position_ids)}'>
                            <i data-feather="edit-3"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger deleteRecord"
                                title="Löschen"
                                data-id="${record.id}">
                            <i data-feather="trash-2"></i>
                        </button>
                    </td>
                </tr>
            `;
        });

        html += `
                </tbody>
            </table>
        `;

        $('#savedRecordsTable').html(html);

        if (window.feather) {
            feather.replace();
        }

        bindRecordButtons();
        initSavedBulkSelectionHandlers();
    }

    function initSavedBulkSelectionHandlers() {
        $('#savedSelectAll').off('change').on('change', function () {
            const checked = $(this).is(':checked');
            $('.savedRowCheckbox').prop('checked', checked);
            updateBulkActionState();
        });

        $('.savedRowCheckbox').off('change').on('change', function () {
            const $all = $('.savedRowCheckbox');
            const checkedCount = $all.filter(':checked').length;

            $('#savedSelectAll').prop('checked', checkedCount === $all.length && $all.length > 0);
            updateBulkActionState();
        });

        updateBulkActionState();
    }

    function updateBulkActionState() {
        const anyChecked = $('.savedRowCheckbox:checked').length > 0;
        $('#btnBulkDuplicate, #btnBulkDelete').prop('disabled', !anyChecked);
    }

    function getSelectedSavedIds() {
        return $('.savedRowCheckbox:checked').map(function () {
            return $(this).data('id');
        }).get();
    }

    function handleBulkDuplicate() {
        const ids = getSelectedSavedIds();

        if (!ids.length) return;

        Swal.fire({
            icon: 'question',
            title: 'Duplizieren',
            text: 'Ausgewählte Vorschläge duplizieren?',
            showCancelButton: true,
            confirmButtonText: 'Ja, duplizieren',
            cancelButtonText: 'Abbrechen'
        }).then(result => {
            if (!result.isConfirmed) return;

            $.ajax({
                url: '/product-position/bulk-duplicate',
                method: 'POST',
                data: { ids },
                headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
                success: function (response) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Dupliziert',
                        text: response.message,
                        timer: 1500,
                        showConfirmButton: false
                    });

                    fetchSavedRecords();
                }
            });
        });
    }

    function handleBulkDelete() {
        const ids = getSelectedSavedIds();

        if (!ids.length) return;

        Swal.fire({
            icon: 'warning',
            title: 'Mehrfach löschen',
            text: 'Ausgewählte Vorschläge wirklich löschen?',
            showCancelButton: true,
            confirmButtonText: 'Ja, löschen',
            cancelButtonText: 'Abbrechen',
            confirmButtonColor: '#d33',
            cancelButtonColor: '#6c757d'
        }).then(result => {
            if (!result.isConfirmed) return;

            $.ajax({
                url: '/product-position/bulk-delete',
                method: 'POST',
                data: { ids },
                headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
                success: function (response) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Gelöscht',
                        text: response.message,
                        timer: 1500,
                        showConfirmButton: false
                    });

                    fetchSavedRecords();
                },
                error: function () {
                    Swal.fire({
                        icon: 'error',
                        title: 'Fehler',
                        text: 'Die Datensätze konnten nicht gelöscht werden.',
                        timer: 1800,
                        showConfirmButton: false
                    });
                }
            });
        });
    }

    function bindRecordButtons() {
        $('.viewEmployees').off('click').on('click', function () {
            const positions = $(this).data('positions') || { internal: [], external: [] };
            const idsInternal = positions.internal || [];
            const idsExternal = positions.external || [];

            $('#employeeBadge').text('Lädt…');
            $('#employeeCountInternal').text('0');
            $('#employeeCountExternal').text('0');
            $('#employeeListInternal').html('<div class="empty">Lädt…</div>');
            $('#employeeListExternal').html('<div class="empty">Lädt…</div>');

            const fetchInternal = ids => $.post('/product-position/employees', {
                position_ids: { internal: ids, external: [] },
                _token: '{{ csrf_token() }}'
            });

            const fetchExternal = ids => $.post('/product-position/employees', {
                position_ids: { internal: [], external: ids },
                _token: '{{ csrf_token() }}'
            });

            $.when(fetchInternal(idsInternal), fetchExternal(idsExternal))
                .done(function (internalResp, externalResp) {
                    const employeesInternal = internalResp[0] || [];
                    const employeesExternal = externalResp[0] || [];

                    renderEmployeesList(employeesInternal, '#employeeListInternal');
                    renderEmployeesList(employeesExternal, '#employeeListExternal');

                    $('#employeeCountInternal').text(employeesInternal.length);
                    $('#employeeCountExternal').text(employeesExternal.length);
                    $('#employeeBadge').text((employeesInternal.length + employeesExternal.length) + ' gesamt');
                })
                .fail(function () {
                    renderEmployeesList([], '#employeeListInternal');
                    renderEmployeesList([], '#employeeListExternal');
                    $('#employeeBadge').text('0 gesamt');
                });
        });

        $('.editRecord').off('click').on('click', function () {
            const recordId = $(this).data('id');
            const stage = $(this).data('stage');
            const produkt = $(this).data('produkt');
            const serviceId = $(this).data('service-id');
            const department = $(this).data('department');
            const posIds = $(this).data('positions') || {};

            $('#editId').val(recordId);
            $('#editStage').val(stage);

            $('#editProduct').empty();
            articleGroups.forEach(group => {
                $('#editProduct').append(`<option value="${group.id}">${group.article_group}</option>`);
            });
            $('#editProduct').val(produkt);

            $('#editDepartment').empty();
            departments.forEach(dept => {
                $('#editDepartment').append(`<option value="${dept.id}">${dept.department_name}</option>`);
            });
            $('#editDepartment').val(department);

            $('#editPositionsInternal').empty();
            $('#editPositionsExternal').empty();

            if (produkt) {
                $.get(`/product-position/services/${produkt}`, function (data) {
                    $('#editService').empty().append('<option value="">Leistung wählen</option>');

                    (data || []).forEach(service => {
                        $('#editService').append(`<option value="${service.id}">${service.label}</option>`);
                    });

                    $('#editService').val(serviceId).trigger('change.select2');
                });
            } else {
                $('#editService').empty().append('<option value="">Leistung wählen</option>');
            }

            if (department) {
                $.get(`/product-position/positions/${department}`, function (data) {
                    (data || []).forEach(position => {
                        const optionHtml = `<option value="${position.id}" data-department-id="${department}">${position.position}</option>`;
                        $('#editPositionsInternal').append(optionHtml);
                        $('#editPositionsExternal').append(optionHtml);
                    });

                    initPositionSelect2($('#editPositionsInternal'));
                    initPositionSelect2($('#editPositionsExternal'));
                    buildPositionEmployeeMapForDepartment(department, data || []);

                    $('#editPositionsInternal').val(posIds.internal || []).trigger('change.select2');
                    $('#editPositionsExternal').val(posIds.external || []).trigger('change.select2');
                });
            }

            $('#editStage, #editProduct, #editService, #editDepartment').select2({
                width: '100%'
            });

            $('#editModal').modal('show');
        });

        $('.deleteRecord').off('click').on('click', function () {
            const id = $(this).data('id');

            Swal.fire({
                title: 'Sind Sie sicher?',
                text: 'Dieser Vorgang kann nicht rückgängig gemacht werden.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ja, löschen',
                cancelButtonText: 'Abbrechen',
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d'
            }).then(result => {
                if (!result.isConfirmed) return;

                $.ajax({
                    url: `/product-position/delete/${id}`,
                    method: 'DELETE',
                    headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
                    success: function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Gelöscht',
                            text: response.message,
                            timer: 1500,
                            showConfirmButton: false
                        });

                        fetchSavedRecords();
                        $('#employeeListInternal').html('<div class="empty">Keine internen Mitarbeiter ausgewählt.</div>');
                        $('#employeeListExternal').html('<div class="empty">Keine externen Mitarbeiter ausgewählt.</div>');
                        $('#employeeBadge').text('0 gefunden');
                        $('#employeeCountInternal').text('0');
                        $('#employeeCountExternal').text('0');
                    },
                    error: function () {
                        Swal.fire({
                            icon: 'error',
                            title: 'Fehler',
                            text: 'Der Datensatz konnte nicht gelöscht werden.',
                            timer: 1800,
                            showConfirmButton: false
                        });
                    }
                });
            });
        });
    }

    function handleEditFormSubmit(e) {
        e.preventDefault();

        const id = $('#editId').val();
        const payload = {
            stage: $('#editStage').val(),
            produkt: $('#editProduct').val(),
            service: $('#editService').val(),
            department: $('#editDepartment').val(),
            positions: {
                internal: $('#editPositionsInternal').val() || [],
                external: $('#editPositionsExternal').val() || []
            }
        };

        const $button = $(this).find('button[type=submit]');
        $button.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> Aktualisieren…');

        $.ajax({
            url: `/product-position/update/${id}`,
            method: 'POST',
            data: payload,
            headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
            success: function (response) {
                Swal.fire({
                    icon: 'success',
                    title: 'Aktualisiert',
                    text: response.message,
                    timer: 1500,
                    showConfirmButton: false
                });

                $('#editModal').modal('hide');
                fetchSavedRecords();
            },
            complete: function () {
                $button.prop('disabled', false).html('<i data-feather="check"></i> Aktualisieren');
                if (window.feather) {
                    feather.replace();
                }
            }
        });
    }
});
</script>
@endsection

