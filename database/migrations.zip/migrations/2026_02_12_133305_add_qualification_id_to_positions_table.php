<?php
// database/migrations/2026_02_12_000002_add_qualification_id_to_positions_table.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        DB::statement("
            UPDATE positions
            SET
              created_at = COALESCE(NULLIF(created_at, '0000-00-00 00:00:00'), NOW()),
              updated_at = COALESCE(NULLIF(updated_at, '0000-00-00 00:00:00'), NOW()),
              deleted_at = NULLIF(deleted_at, '0000-00-00 00:00:00')
        ");

        // 1) Add column first (no FK yet)
        Schema::table('positions', function (Blueprint $table) {
            if (!Schema::hasColumn('positions', 'qualification_id')) {
                $table->unsignedBigInteger('qualification_id')->nullable()->after('id');
            }
        });

        // 2) Backfill qualification table + assign ids
        $existing = DB::table('positions')
            ->select('qualification', 'price')
            ->whereNotNull('qualification')
            ->where('qualification', '!=', '')
            ->groupBy('qualification', 'price')
            ->get();

        foreach ($existing as $row) {
            $qid = DB::table('position_qualifications')
                ->where('name', $row->qualification)
                ->value('id');

            if (!$qid) {
                $qid = DB::table('position_qualifications')->insertGetId([
                    'name' => $row->qualification,
                    'default_price' => $row->price ?? 0,
                    'sort_order' => 0,
                    'status' => 'Published',
                    'created_at' => now(),
                    'updated_at' => now(),
                    'deleted_at' => null,
                ]);
            }

            DB::table('positions')
                ->where('qualification', $row->qualification)
                ->whereNull('qualification_id')
                ->update(['qualification_id' => $qid]);
        }

        // 3) Now add FK constraint (drop if half-created before)
        Schema::table('positions', function (Blueprint $table) {
            try { $table->dropForeign('positions_qualification_id_foreign'); } catch (\Throwable $e) {}

            $table->foreign('qualification_id', 'positions_qualification_id_foreign')
                ->references('id')->on('position_qualifications')
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('positions', function (Blueprint $table) {
            try { $table->dropForeign('positions_qualification_id_foreign'); } catch (\Throwable $e) {}
            if (Schema::hasColumn('positions', 'qualification_id')) {
                $table->dropColumn('qualification_id');
            }
        });
    }
};
