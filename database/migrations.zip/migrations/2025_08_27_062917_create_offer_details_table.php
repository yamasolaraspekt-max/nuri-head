<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
         Schema::create('offer_details', function (Blueprint $table) {
            $table->id();

            $table->foreignId('offer_id')->constrained('offers')->cascadeOnDelete();
            $table->foreignId('folder_id')->constrained('offer_folders')->cascadeOnDelete();
            $table->unique(['offer_id','folder_id']);  

            // Step A
            $table->string('property_type')->nullable();
            $table->string('zip',16)->nullable();
            $table->string('city',120)->nullable();
            $table->smallInteger('year_built')->nullable();
            $table->string('insulation')->default('durchschnittlich');
            $table->decimal('area_m2', 10, 2)->nullable();
            $table->decimal('ceiling_m', 5, 2)->nullable();
            $table->unsignedTinyInteger('occupants')->nullable();

            // Step B
            $table->string('current_source')->nullable();
            $table->string('emitters')->nullable();
            $table->decimal('lowest_flow_c', 6, 2)->nullable();
            $table->unsignedInteger('dhw_cyl')->nullable();

            // Step C
            $table->unsignedInteger('annual_kwh')->nullable();
            $table->unsignedSmallInteger('age_years')->nullable();
            $table->string('heating_tech')->nullable();
            $table->unsignedTinyInteger('persons')->nullable();
            $table->unsignedInteger('dhw_per_person')->nullable();

            // Step D
            $table->decimal('vl', 6, 2)->nullable();
            $table->decimal('rl', 6, 2)->nullable();
            $table->decimal('delta', 6, 2)->nullable();
            $table->string('distribution')->nullable();
            $table->smallInteger('nat')->nullable();
            $table->decimal('biv', 5, 2)->nullable();
            $table->decimal('ti', 5, 2)->nullable();
            $table->decimal('wp_share_pct', 5, 2)->nullable();
            $table->unsignedInteger('flh')->nullable();
            $table->decimal('peak_factor', 5, 2)->nullable();
            $table->decimal('dist_mult', 5, 2)->nullable();
            $table->decimal('vl_mult', 5, 2)->nullable();

            // Derived
            $table->decimal('actual_total_kwh', 12, 2)->nullable();
            $table->decimal('dhw_total_kwh', 12, 2)->nullable();
            $table->decimal('heating_kwh', 12, 2)->nullable();
            $table->decimal('q_avg_kw', 10, 3)->nullable();
            $table->decimal('q_nat_kw', 10, 3)->nullable();
            $table->decimal('f_biv', 6, 3)->nullable();
            $table->decimal('t_biv', 5, 2)->nullable();         // <- NEU
            $table->decimal('age_loss_factor', 5, 4)->nullable(); // <- optional, NEU
            $table->decimal('jaz_raw', 5, 2)->nullable();
            $table->decimal('jaz_used', 5, 2)->nullable();
            $table->decimal('elec_wp_kwh', 12, 2)->nullable();
            $table->decimal('elec_estab_kwh', 12, 2)->nullable();
            $table->decimal('elec_total_kwh', 12, 2)->nullable();
            $table->decimal('hp_size_kw', 8, 2)->nullable();
            $table->decimal('hp_reco_kw', 8, 2)->nullable();

            // Kalkulation / Angebot – wähle Einzelspalten ODER Snapshots (oder beides)
            $table->decimal('k_mat_ek', 12, 2)->nullable();
            $table->decimal('k_klein_ek', 12, 2)->nullable();
            $table->decimal('k_transport', 12, 2)->nullable();
            $table->decimal('k_gk_vertrieb', 5, 2)->nullable();
            $table->decimal('k_gk_buv', 5, 2)->nullable();
            $table->decimal('k_gk_wagnis', 5, 2)->nullable();
            $table->decimal('k_z_mat', 5, 2)->nullable();
            $table->decimal('k_z_lohn', 5, 2)->nullable();

            $table->decimal('global_discount_pct', 5, 2)->nullable();
            $table->decimal('shipping_net_eur', 12, 2)->nullable();
            $table->boolean('apply_global_to_shipping')->default(false);
 
            $table->boolean('include_tools')->default(true);

            $table->json('positions_json')->nullable();       // alternativ: eigene Tabelle
            $table->json('calc_snapshot')->nullable();        // optional
            $table->json('offer_snapshot')->nullable();       // optional

            $table->json('bootstrap_snapshot')->nullable();
            $table->json('meta')->nullable();

            $table->timestamps(); 
        });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('offer_details');
    }
};
