<?php

 
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::table('breaking_news', function (Blueprint $table) {
            $table->string('audio_path')->nullable()->after('message');
        });
    }

    public function down()
    {
        Schema::table('breaking_news', function (Blueprint $table) {
            $table->dropColumn('audio_path');
        });
    }
};

