<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('maintenance_assets')) {
            return;
        }

        // 1) Drop old FK (if exists)
        Schema::table('maintenance_assets', function (Blueprint $table) {
            if (Schema::hasColumn('maintenance_assets', 'maintenance_contract_id')) {
                // drops FK constraint on the column (Laravel resolves name if conventional)
                $table->dropForeign(['maintenance_contract_id']);
                // optional: drop index if it exists (if created separately)
                // $table->dropIndex(['maintenance_contract_id']);
            }
        });

        // 2) Rename column
        Schema::table('maintenance_assets', function (Blueprint $table) {
            if (Schema::hasColumn('maintenance_assets', 'maintenance_contract_id')
                && !Schema::hasColumn('maintenance_assets', 'customer_maintenance_contract_id')) {
                $table->renameColumn('maintenance_contract_id', 'customer_maintenance_contract_id');
            }
        });

        // 3) Add new FK + index
        Schema::table('maintenance_assets', function (Blueprint $table) {
            if (Schema::hasColumn('maintenance_assets', 'customer_maintenance_contract_id')) {
                $table->foreign('customer_maintenance_contract_id')
                    ->references('id')
                    ->on('customer_maintenance_contracts')
                    ->nullOnDelete();

                // if you want an index and it doesn't already exist
                $table->index('customer_maintenance_contract_id');
            }
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('maintenance_assets')) {
            return;
        }

        // 1) Drop new FK
        Schema::table('maintenance_assets', function (Blueprint $table) {
            if (Schema::hasColumn('maintenance_assets', 'customer_maintenance_contract_id')) {
                $table->dropForeign(['customer_maintenance_contract_id']);
                // optional:
                // $table->dropIndex(['customer_maintenance_contract_id']);
            }
        });

        // 2) Rename column back
        Schema::table('maintenance_assets', function (Blueprint $table) {
            if (Schema::hasColumn('maintenance_assets', 'customer_maintenance_contract_id')
                && !Schema::hasColumn('maintenance_assets', 'maintenance_contract_id')) {
                $table->renameColumn('customer_maintenance_contract_id', 'maintenance_contract_id');
            }
        });

        // 3) Restore old FK
        Schema::table('maintenance_assets', function (Blueprint $table) {
            if (Schema::hasColumn('maintenance_assets', 'maintenance_contract_id')) {
                $table->foreign('maintenance_contract_id')
                    ->references('id')
                    ->on('maintenance_contracts')
                    ->nullOnDelete();
            }
        });
    }
};
